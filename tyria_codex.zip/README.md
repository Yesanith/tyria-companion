# Tyria Codex

Guild Wars 2 companion app (Flutter). Karakterler, hesap (cüzdan, banka, materyaller),
Wizard's Vault günlükleri ve Guild Wars 2 Wiki araması.

## Yapı
- `lib/api/` — GW2 API v2 ve wiki (MediaWiki) istemcileri
- `lib/state/providers.dart` — Riverpod provider'ları
- `lib/screens/` — ekranlar (giriş, ana sayfa, karakterler, karakter detayı, hesap, wiki, ayarlar)
- `lib/widgets/common.dart` — ortak bileşenler
- `.github/workflows/build.yml` — APK derleyen GitHub Actions workflow'u

`android/` klasörü repoda yok; workflow ilk derlemede `flutter create` ile üretir.
Lokal derleme için: `flutter create --platforms=android --org com.yesanith --project-name tyria_codex .`
sonra `flutter build apk --release`.

Tyria Codex resmi olmayan bir hayran uygulamasıdır.
